from fastapi import FastAPI
from pydantic import BaseModel
from backend.summarizer import generate_mom

app = FastAPI()

class TranscriptRequest(BaseModel):
    transcript: str

@app.post("/generate")
def generate(request: TranscriptRequest):
    result = generate_mom(request.transcript)
    return {"data": result}