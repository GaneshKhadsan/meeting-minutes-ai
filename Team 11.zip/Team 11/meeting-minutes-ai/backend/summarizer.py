from openai import OpenAI
import httpx
import os
from dotenv import load_dotenv
import json

# Load environment variables from .env
load_dotenv()

# Get API key securely
API_KEY = os.getenv("GENAI_API_KEY")

if not API_KEY:
    raise ValueError("GENAI_API_KEY not found in environment variables")

# Create HTTP client
client = httpx.Client(verify=False)

# Create LLM client
llm_client = OpenAI(
    base_url="https://genailab.tcs.in",
    http_client=client,
    api_key=API_KEY
)

LLM_MODEL = "genailab-maas-gpt-4o"


def generate_mom(transcript: str):

    prompt = f"""
You are a Senior Program Management Assistant.

From the meeting transcript below extract:

1. Executive Summary
2. Key Decisions (as list)
3. Action Items with:
   - description
   - owner
   - due_date
   - priority (High/Medium/Low)
4. Risks (as list)

Return STRICT JSON in this format:

{{
  "summary": "",
  "key_decisions": [],
  "action_items": [
    {{
      "description": "",
      "owner": "",
      "due_date": "",
      "priority": "",
      "status": "Open"
    }}
  ],
  "risks": []
}}

Do not return markdown.
Do not explain anything.
Only valid JSON.

Transcript:
{transcript}
"""

    try:
        response = llm_client.chat.completions.create(
            model=LLM_MODEL,
            temperature=0.1,
            messages=[{"role": "user", "content": prompt}]
        )

        raw_output = response.choices[0].message.content.strip()

        # Optional: Validate JSON format
        parsed_json = json.loads(raw_output)

        return parsed_json

    except Exception as e:
        return {"error": str(e)}