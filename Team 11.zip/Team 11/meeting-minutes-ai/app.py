import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import json
from fpdf import FPDF
import yagmail
import os
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(layout="wide")
st.title("📋 AI Meeting Minutes Generator")

# =========================
# PDF Generator
# =========================
def generate_pdf(data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=10)

    pdf.cell(0, 10, "MEETING MINUTES", ln=True)
    pdf.ln(5)

    pdf.multi_cell(0, 6, "Executive Summary:")
    pdf.multi_cell(0, 6, data["summary"])
    pdf.ln()

    pdf.multi_cell(0, 6, "Key Decisions:")
    for decision in data["key_decisions"]:
        pdf.multi_cell(0, 6, f"- {decision}")
    pdf.ln()

    pdf.multi_cell(0, 6, "Risks:")
    for risk in data["risks"]:
        pdf.multi_cell(0, 6, f"- {risk}")
    pdf.ln()

    pdf.multi_cell(0, 6, "Action Items:")
    for item in data["action_items"]:
        pdf.multi_cell(
            0,
            6,
            f"- {item.get('description','')} | "
            f"Owner: {item.get('owner','')} | "
            f"Due: {item.get('due_date','')} | "
            f"Status: {item.get('status','')}"
        )

    return pdf.output(dest="S").encode("latin-1")


# =========================
# Generate Button Section
# =========================
transcript = st.text_area("Paste Meeting Transcript Here", height=250)

if st.button("Generate MoM"):

    if transcript.strip() == "":
        st.warning("Please enter transcript")

    else:
        with st.spinner("Generating Minutes..."):

            response = requests.post(
                "http://127.0.0.1:8000/generate",
                json={"transcript": transcript}
            )

            result = response.json()

            if "data" in result:

                data = result["data"]

                if isinstance(data, dict):
                    parsed = data
                else:
                    parsed = json.loads(data)

                # ✅ STORE OUTPUT IN SESSION STATE
                st.session_state["parsed_output"] = parsed

            else:
                st.error("Error generating minutes")


# =========================
# DISPLAY SECTION (Persistent)
# =========================
if "parsed_output" in st.session_state:

    parsed = st.session_state["parsed_output"]

    st.success("Minutes Generated Successfully!")

    # Summary
    st.subheader("Executive Summary")
    st.write(parsed.get("summary", ""))

    # Decisions
    st.subheader("Key Decisions")
    for decision in parsed.get("key_decisions", []):
        st.write("•", decision)

    # Risks
    st.subheader("Risks")
    for risk in parsed.get("risks", []):
        st.write("•", risk)

    # =========================
    # Action Items Table
    # =========================
    st.subheader("Action Items")

    if "edited_actions" not in st.session_state:
        df = pd.DataFrame(parsed.get("action_items", []))
        if "status" not in df.columns:
            df["status"] = "Open"
        st.session_state["edited_actions"] = df

    edited_df = st.data_editor(
        st.session_state["edited_actions"],
        use_container_width=True,
        num_rows="dynamic",
        key="action_table"
    )

    # 🔥 Save edits automatically
    st.session_state["edited_actions"] = edited_df.copy()

    # =========================
    # Charts (Based on Edited Data)
    # =========================
    st.subheader("📊 Analytics")

    col1, col2 = st.columns(2)

    with col1:
        if "owner" in edited_df.columns:
            owner_counts = edited_df["owner"].value_counts().reset_index()
            owner_counts.columns = ["owner", "count"]

            fig_bar = px.bar(
                owner_counts,
                x="owner",
                y="count",
                color="owner",
                text="count",
                title="Action Items by Owner"
            )

            st.plotly_chart(fig_bar, use_container_width=True)

    with col2:
        if "status" in edited_df.columns:
            status_counts = edited_df["status"].value_counts().reset_index()
            status_counts.columns = ["status", "count"]

            fig_pie = px.pie(
                status_counts,
                names="status",
                values="count",
                title="Open vs Closed Distribution"
            )

            st.plotly_chart(fig_pie, use_container_width=True)

    # =========================
    # Download Section
    # =========================
    st.subheader("⬇ Download Options")

    final_output = {
        "summary": parsed.get("summary", ""),
        "key_decisions": parsed.get("key_decisions", []),
        "risks": parsed.get("risks", []),
        "action_items": edited_df.to_dict(orient="records")
    }

    # JSON Download
    st.download_button(
        label="Download as JSON",
        data=json.dumps(final_output, indent=4),
        file_name="meeting_minutes.json",
        mime="application/json"
    )

    # PDF Download
    pdf_bytes = generate_pdf(final_output)

    st.download_button(
        label="Download as PDF",
        data=pdf_bytes,
        file_name="meeting_minutes.pdf",
        mime="application/pdf"
    )

    # =========================
    # Email Sharing
    # =========================
    st.subheader("📧 Share via Email")

    recipient = st.text_input("Recipient Email")

    if st.button("Send Email"):

        try:
            with open("meeting_minutes.pdf", "wb") as f:
                f.write(pdf_bytes)

            yag = yagmail.SMTP(
                os.getenv("EMAIL_USER"),
                os.getenv("EMAIL_PASS")
            )

            yag.send(
                to=recipient,
                subject="Meeting Minutes",
                contents="Please find attached meeting minutes.",
                attachments="meeting_minutes.pdf"
            )

            st.success("Email Sent Successfully!")

        except Exception as e:
            st.error(f"Email failed: {e}")